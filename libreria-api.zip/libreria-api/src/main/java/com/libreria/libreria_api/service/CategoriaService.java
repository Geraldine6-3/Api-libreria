package com.libreria.libreria_api.service;

import com.libreria.libreria_api.model.Categoria;
import com.libreria.libreria_api.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    public List<Categoria> findAll() {
        return categoriaRepository.findAll();
    }

    public Categoria findById(Long id) {
        return categoriaRepository.findById(id).orElse(null);
    }

    public Categoria save(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    public Categoria update(Long id, Categoria categoriaActualizada) {
        Categoria categoriaExistente = findById(id);
        if (categoriaExistente != null) {
            categoriaExistente.setNombre(categoriaActualizada.getNombre());
            return categoriaRepository.save(categoriaExistente);
        }
        return null;
    }

    public void deleteById(Long id) {
        categoriaRepository.deleteById(id);
    }
}