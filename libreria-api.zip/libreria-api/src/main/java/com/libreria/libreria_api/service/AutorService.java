package com.libreria.libreria_api.service;

import com.libreria.libreria_api.model.Autor;
import com.libreria.libreria_api.repository.AutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AutorService {

    @Autowired
    private AutorRepository autorRepository;

    public List<Autor> findAll() {
        return autorRepository.findAll();
    }

    public Autor save(Autor autor) {
        return autorRepository.save(autor);
    }

    public Autor findById(Long id) {
        return autorRepository.findById(id).orElse(null);
    }

    public void deleteById(Long id) {
        autorRepository.deleteById(id);
    }
}