package com.libreria.libreria_api.repository;

import com.libreria.libreria_api.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {}