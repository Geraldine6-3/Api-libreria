package com.libreria.libreria_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibreriaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibreriaApiApplication.class, args);
	}

}
