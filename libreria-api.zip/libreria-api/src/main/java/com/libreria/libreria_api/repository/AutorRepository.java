package com.libreria.libreria_api.repository;

import com.libreria.libreria_api.model.Autor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutorRepository extends JpaRepository<Autor, Long> {

}